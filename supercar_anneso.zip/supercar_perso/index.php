<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Accueil</title>

</head>

<body>

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
      </nav>


    <!-- Section hero -->
    <section class="hero-section">

        <video autoplay muted loop>
            <source src="images/accueil.mp4" type="video/mp4">
        </video>

        <div class="hero-content text-center">
            <h2>Supercar</h2>
            <h3><i>Depuis 2009</i></h3>
            <a href="#a_propos" class="button">À propos 
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" 
                     class="bi bi-caret-right-fill" viewBox="0 0 16 16">
                    <path d="m12.14 8.753-5.482 4.796c-.646.566-1.658.106-1.658-.753V3.204a1 1 0 0 1 1.659-.753l5.48 4.796a1 1 0 0 1 0 1.506z"/>
                </svg>
            </a>
        </div>

    </section>

    <!-- Section des services -->
    <section class="service-section py-5">

        <div class="container">
            <div class="container my-5 text-center">
                <h2>Nos services</h2>
            </div>

            <div class="row text-center my-5">

                <!-- Lavage -->
                <div class="col-md-3">
                    <a href="services.php">
                        <div class="round-container my-4">
                            <img src="images/icon_wash.png" alt="Image Lavage">
                        </div>
                    </a>
                    <p>Lavage</p>
                </div>

                <!-- Réparation -->
                <div class="col-md-3">
                    <a href="services.php">
                        <div class="round-container my-4">
                            <img src="images/icon_tool.png" alt="Image Réparation">
                        </div> 
                    </a>
                    <p>Réparation</p>
                </div>
                
                <!-- Maintenance -->
                <div class="col-md-3">
                    <a href="services.php">
                        <div class="round-container my-4">
                            <img src="images/icon_servicing.png" alt="Image Maintenance">
                        </div>
                    </a>
                    <p>Maintenance</p>
                </div>

            </div>
        </div>

    </section>

    <!-- Section à propos -->
    <section class="about-section py-5" id="a_propos">

        <div class="container">
            <div class="container my-5 text-center">
                <h2>À propos</h2>
            </div>

     

            <div class="row my-5">
            <?php
        include("config.php");
        $selection = "SELECT * FROM accueil WHERE id_accueil = '1'";
        $curseur = mysqli_query($bdd, $selection);


        if ($curseur) {
    // Assurez-vous qu'il y a des résultats à afficher
            if (mysqli_num_rows($curseur) > 0) {
                while ($row = mysqli_fetch_array($curseur)) {
                    $v_a_propos = $row["a_propos"];
                    $v_image_accueil = $row["image_accueil"];

              
                    echo "<div class='col-lg m-auto'>";
                    echo $v_a_propos;
                    echo "</div>";
                    
                    echo "<div class='col-lg m-auto'>";
                    echo "<img src='$v_image_accueil' width = '100%'> ";
                    echo "</div>";
                    

                    

           
        }

        // Libérer la mémoire du serveur de la variable $curseur
        mysqli_free_result($curseur);
            } else {
        // Gérer le cas où la requête ne renvoie pas de résultats
                echo "Aucun résultat trouvé.";
                }
        } else {
    // Gérer l'erreur si la requête échoue
    echo "Erreur de requête : " . mysqli_error($bdd);
        }
        ?>
  </div>

         </div>
        </div>

    </section>

    
    <section class="footer py-4">

        <div class="container">
            <div class="container my-4">
                <h4>Supercar © Copyright by Supercar</h4>
            </div>

            <div class="row text-center my-4">

                <!-- Lavage -->
                <div class="col-md-3">
                    <a href="contact.php">
                        Contact
                    </a>
                </div>

                <!-- Réparation -->
                <div class="col-md-3">
                    <a href="mentions.php">
                        Mentions légales
                    </a>
                </div>
                
                <!-- Maintenance -->
                <div class="col-md-3">
                    <a href="politique.php">
                        Politiques de confidentialité
                    </a>
                </div>

            </div>
        </div>

    </section>
</body>
</html>


 
        

    