<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Accueil</title>

</head>

<body style="background-color: #FAFAFA;">

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
    </nav>


    <?php
    session_start();
    include("config.php");

    // Vérifier si l'utilisateur est connecté
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php"); // Rediriger vers login si non connecté
        exit();
    }

    $v_modele = isset($_GET['modele']) ? htmlspecialchars($_GET['modele']) : '';

    // Récupérer la liste des modèles de la base de données
    $query = "SELECT modele FROM voiture";
    $stmt = $bdd->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    $models = [];
    while ($row = $result->fetch_assoc()) {
        $models[] = $row['modele'];
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupérer les valeurs du formulaire
        $v_modele = htmlspecialchars($_POST['modele']);
        $v_date = htmlspecialchars($_POST['date']);
        $v_heure = htmlspecialchars($_POST['heure']);
        $v_username = $_SESSION['username']; // Le nom du client connecté
        
        // Récupérer l'ID de la voiture (id_voiture) en fonction du modèle
        $query = "SELECT id_voiture FROM voiture WHERE modele = ?";
        $stmt = $bdd->prepare($query);
        $stmt->bind_param("s", $v_modele);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $v_id_voiture = $row['id_voiture'];

            $query = "INSERT INTO demande_essai (voiture, date_demande, heure_demande, username_client, statut) 
          VALUES (?, ?, ?, ?, 'En attente')";
$stmt = $bdd->prepare($query);
$stmt->bind_param("isss", $v_id_voiture, $v_date, $v_heure, $v_username);
$stmt->execute();

            if ($stmt->affected_rows > 0) {
                $status = "Demande d'essai enregistrée avec succès!";
            } else {
                $status = "Erreur lors de l'enregistrement de la demande.";
            }
        } else {
            $status = "Modèle non trouvé dans la base de données.";
        }

        $stmt->close();
    }

?>




<div class="container mt-5 d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="row w-100">
        <!-- Colonne pour l'image (Google Maps) -->
        <div class="col-xl-7 col-md-12 mb-4">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14407.819577038661!2d57.47680847186359!3d-20.24369805547519!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b1ef2170f63%3A0xd1a78020fc096491!2sMCCI%20BUSINESS%20SCHOOL%20(Mauritius%20Chamber%20of%20Commerce%20and%20Industry)!5e0!3m2!1sen!2smu!4v1741702609435!5m2!1sen!2smu" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>        
        </div>
        
        <!-- Colonne pour le formulaire -->
        <div class="col-xl-5 col-md-12 p-4 border rounded shadow-sm d-flex flex-column justify-content-center">
            
            <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <h2 class="text-center">Demande d'essai pour la voiture</h2>

                <div class="row">
            <div class="col-md-12">
                <label for="modele" class="form-label mt-2">Modèle</label>
                <?php if ($v_modele) { ?>
                    <!-- Si un modèle est sélectionné, le champ est en read-only -->
                    <input type="text" id="modele" name="modele" value="<?php echo htmlspecialchars($v_modele); ?>" class="form-control" readonly required>
                <?php } else { ?>
                    <!-- Sinon, afficher la liste déroulante des modèles -->
                    <select id="modele" name="modele" class="form-control" required>
                        <option value="" disabled selected>Choisir un modèle</option>
                        <?php foreach ($models as $modele) { ?>
                            <option value="<?php echo htmlspecialchars($modele); ?>"><?php echo htmlspecialchars($modele); ?></option>
                        <?php } ?>
                    </select>
                <?php } ?>
            </div>

            <div class="col-md-6 mt-3">
                <label for="date" class="form-label">Date de l'essai</label>
                <input type="date" id="dateField" name="date" class="form-control" required>
            </div>

            <div class="col-md-6 mt-3">
                <label for="heure" class="form-label">Heure de l'essai</label>
                <input type="time" id="heureField" name="heure" class="form-control" required>
            </div>
        
            <!-- Ajout du menu deroulant -->
       
        </div>

                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" class="form-control button btn-sm mt-3">Envoyer</button>
                    </div>
                    <div class="col-md-6">
                        <button type="reset" class="form-control button btn-sm mt-3">Annuler</button>
                    </div>
                </div>

                <div id="status" class="mt-2">
                    <?php if (isset($status)) echo $status; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const dateField = document.getElementById("dateField");
        const heureField = document.getElementById("heureField");

        // Fixer min date au jour d'aujourd'hui (format yyyy-mm-dd)
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0'); // mois commence à 0
        const dd = String(today.getDate()).padStart(2, '0');
        const todayStr = `${yyyy}-${mm}-${dd}`;
        dateField.min = todayStr;

        dateField.addEventListener("input", function () {
            const selectedDate = new Date(this.value);
            const jourSemaine = selectedDate.getDay(); // 0 = Dimanche

            // Vérifier que la date n'est pas antérieure à aujourd'hui
            if (this.value < todayStr) {
                alert("La date ne peut pas être antérieure à aujourd'hui.");
                this.value = "";
                return;
            }

            // Vérifier que ce n'est pas un dimanche
            if (jourSemaine === 0) {
                alert("Le service n'est pas disponible le dimanche. Choisissez un autre jour.");
                this.value = "";
            }
        });

        // Empêcher la sélection d'heures en dehors des horaires de travail
        heureField.addEventListener("input", function () {
            if (this.value < "09:00" || this.value > "17:00") {
                alert("Les horaires de service sont de 09h00 à 17h00.");
                this.value = "";
            }
        });
    });
</script>



</body>
</html>
