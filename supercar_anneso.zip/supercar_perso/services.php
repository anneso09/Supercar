<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Services</title>

</head>

<body style="background-color: #FAFAFA;">

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
    </nav>

    <?php
include("config.php");

// Récupération des services depuis la base de données
$service_query = "SELECT * FROM service";
$service_result = mysqli_query($bdd, $service_query);
$services = [];

if ($service_result) {
    while ($row = mysqli_fetch_assoc($service_result)) {
        $services[] = $row;
    }
}
?>

<section class="service-section py-5">
    <div class="container">
        <div class="container my-5 text-center">
            <h2>Nos services</h2>
        </div>
        <div class="row text-center my-5">
            <?php foreach ($services as $service): ?>
                <div class="col-md-3">
                    <a href="#" data-bs-toggle="modal" data-bs-target="#modal_<?php echo $service['id_service']; ?>">
                        <div class="round-container my-4">
                            <img src="<?php echo htmlspecialchars($service['icon_service']); ?>" alt="Image <?php echo htmlspecialchars($service['type_service']); ?>">
                        </div>
                    </a>
                    <p><?php echo htmlspecialchars($service['type_service']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php foreach ($services as $service): ?>
    <div class="modal fade" id="modal_<?php echo $service['id_service']; ?>" tabindex="-1" aria-labelledby="modal_<?php echo $service['id_service']; ?>Label" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo htmlspecialchars($service['type_service']); ?></h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                <img src="<?php echo htmlspecialchars($service['image_service']); ?>" class="d-block mx-auto rounded mb-3 img-fluid" style="max-width: 70%; height: auto;" alt="<?php echo htmlspecialchars($service['type_service']); ?>">

                    <p><?php echo htmlspecialchars($service['description_service']); ?></p>
                </div>
                <div class="modal-footer">
                <button class="button" onclick="location.href='service.php?id_service=<?php echo urlencode($service['id_service']); ?>'">Prendre rendez-vous</button>
            </div>
            

            </div>
        </div>
    </div>
<?php endforeach; ?>

</section>



    <section class="footer py-4">
        <div class="container">
            
            <div class="container my-4">
                <h4>Supercar © Copyright by Supercar</h4>
            </div>

            <div class="row text-center my-4">
                
                <div class="col-md-3">
                    <a href="contact.php">
                        Contact
                    </a>
                </div>
    
                <div class="col-md-3">
                    <a href="mentions.php">
                        Mentions légales
                    </a>
                </div>
                
                <div class="col-md-3">
                    <a href="politique.php">
                        Politiques de confidentialité
                    </a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>