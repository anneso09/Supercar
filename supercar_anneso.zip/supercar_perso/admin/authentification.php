<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="../style.css" rel="stylesheet">
   

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Authentification</title>

</head>
<nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="../images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>
        </div>
</nav>

<body>
    
<?php
session_start();
include("../config.php"); // Connexion à la base de données

// Constantes pour le chiffrement
define('SECRET_KEY', 'Clé$uperCar');
define('CIPHER_METHOD', 'AES-256-CBC');

// Fonction pour déchiffrer un mot de passe
function decrypt_password($encrypted) {
    list($encrypted_data, $iv) = explode('::', base64_decode($encrypted), 2);
    return openssl_decrypt($encrypted_data, CIPHER_METHOD, SECRET_KEY, 0, $iv);
}

// Connexion admin
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['fieldUsername'], $_POST['fieldPassword'])) {
    $v_username = mysqli_real_escape_string($bdd, $_POST["fieldUsername"]);
    $v_password = $_POST["fieldPassword"];

    // Requête pour récupérer les informations de l'admin
    $query = "SELECT * FROM admin WHERE username_admin = ?";
    $stmt = mysqli_prepare($bdd, $query);
    mysqli_stmt_bind_param($stmt, "s", $v_username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        //On déchiffre le mot de passe de la BDD
        $decrypted_password = decrypt_password($user['password_admin']);

        // Vérification
        if ($v_password === $decrypted_password) {
            $_SESSION['admin_id'] = $user['id_admin'];
            $_SESSION['username_admin'] = $v_username;
            $_SESSION['prenom_admin'] = $user['prenom_admin'];

            //Redirection vers la page admin (à adapter si tu veux une autre page)
            header("Location: dashboard.php");
            exit();
        } else {
            $status = "Mot de passe ou utilisateur incorrect.";
        }
    } else {
        $status = "Mot de passe ou utilisateur incorrect.";
    }

    mysqli_stmt_free_result($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($bdd);
}
?>



<div class="container d-flex justify-content-center align-items-center" style="min-height: 85vh;">
   
        <!-- Colonne pour le formulaire -->
        <div class="col-xl-5 p-5 border rounded shadow-sm d-flex flex-column justify-content-center">
            <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <h2 class="text-center">Connexion Admin</h2>

                <div class="row">
                    <div class="col-md-6">
                        <label for="username" class="form-label mt-5">Nom d'utilisateur</label>
                        <input type="text" class="form-control form-control-sm" name="fieldUsername" required>
                    </div>
                    <div class="col-md-6">
                        <label for="password" class="form-label mt-5">Mot de passe</label>
                        <input type="password" class="form-control form-control-sm" name="fieldPassword" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" class="form-control button btn-sm mt-5">Envoyer</button>
                    </div>
                    <div class="col-md-6">
                        <button type="reset" class="form-control button btn-sm mt-5">Annuler</button>
                    </div>
                </div>

                
                
            </form>
        </div>
    </div>
</div>



</body>
</html>