<?php
session_start();
include("../config.php");

if (!isset($_SESSION['prenom_admin']) || !isset($_SESSION['admin_id'])) {
header('Location: authentification.php');
exit();
}

// Récupération de l'id_demande depuis GET

$id_demande = $_GET['id_demande'];
//$id_admin = $_SESSION['admin_id'];

//Mise à jour du statut
$result = mysqli_query($bdd, "
    UPDATE demande_essai 
    SET statut = 'Annulée', 
    WHERE id_demande = $id_demande
");//
// $result = mysqli_query($bdd, "
//     UPDATE demande_essai 
//     SET statut = 'Annulée', 
//         updated_by = $id_admin
//     WHERE id_demande = $id_demande
// ");


// Redirection
header("Location:demande_essai.php");

// $result = mysqli_query($bdd, "
//     UPDATE demande_essai 
//     SET statut = 'Annulée', 
//         updated_by = $id_admin
//     WHERE id_demande = $id_demande
// ");

?>
