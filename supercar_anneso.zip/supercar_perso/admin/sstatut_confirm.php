<?php 
include("../config.php");
$id_demande = $_GET['id_demande_service'];
$result = mysqli_query($bdd, "UPDATE demande_service SET statut = 'Acceptée' WHERE id_demande_service = $id_demande");
header("Location:demande_service.php");
?>