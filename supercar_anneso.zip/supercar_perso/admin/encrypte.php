<?php
define('SECRET_KEY', 'Clé$uperCar');
define('CIPHER_METHOD', 'AES-256-CBC');

// Fonction pour chiffrer un mot de passe
function encrypt_password($password) {
    $iv_length = openssl_cipher_iv_length(CIPHER_METHOD);
    $iv = openssl_random_pseudo_bytes($iv_length);
    $encrypted = openssl_encrypt($password, CIPHER_METHOD, SECRET_KEY, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

// Le mot de passe à chiffrer
$password = "admin"; // Remplace ici par le mot de passe que tu veux
$encrypted_password = encrypt_password($password);

// Afficher le mot de passe chiffré
echo "Mot de passe chiffré : " . $encrypted_password;
?>
