<?php 
include("../config.php");
$id_demande = $_GET['id_demande'];
$result = mysqli_query($bdd, "UPDATE demande_essai SET statut = 'Terminée' WHERE id_demande = $id_demande");
header("Location:demande_essai.php");
?>