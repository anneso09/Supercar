<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="../style.css" rel="stylesheet">
    <link href = "styleAdmin.css" rel = "stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <title>Tableau de bord Admin</title>

</head>

<body>


    <?php
    session_start();
    if (!isset($_SESSION['prenom_admin'])) {
        header('Location: authentification.php');
        exit();
    }
    include("../config.php");
    ?>


        <button class="btn btn-outline-secondary d-xl-none m-3" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar">
          ☰ Menu
        </button>

        <!-- Sidebar (visible uniquement en md et +) -->
        <div class="d-none d-xl-flex col-xl-2 sidebar position-fixed p-3 flex-column justify-content-center">
          <div class="navbar-brand mb-5 me-auto">
            <img src="../images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
            SUPERCAR
          </div>
          <h5 >Menu</h5>
          <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="car.php">Voitures</a></li>
            <li class="nav-item"><a class="nav-link" href="demande_essai.php">Demandes d'essais</a></li>
            <li class="nav-item"><a class="nav-link" href="demande_service.php">Demandes de services</a></li>
            <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
            <li class="nav-item"><a class="nav-link" href="accueil.php">Accueil</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php">Messages</a></li>
            <li class="nav-item"><a class="nav-link active" href="client.php">Clients</a></li>
            <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Déconnexion</a></li>
          </ul>
        </div>


        <!-- Offcanvas (mobile seulement) -->
        <div class="offcanvas offcanvas-start d-xl-none" tabindex="-1" id="mobileSidebar">
          <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
          </div>
          <div class="offcanvas-body">
            <ul class="nav flex-column">
              <li class="nav-item"><a class="nav-link active" href="car.php">Voitures</a></li>
              <li class="nav-item"><a class="nav-link" href="demande_essai.php">Demandes d'essais</a></li>
              <li class="nav-item"><a class="nav-link" href="demande_service.php">Demandes de services</a></li>
              <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
              <li class="nav-item"><a class="nav-link" href="accueil.php">Accueil</a></li>
              <li class="nav-item"><a class="nav-link" href="contact.php">Messages</a></li>
              <li class="nav-item"><a class="nav-link active" href="client.php">Clients</a></li>
              <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Déconnexion</a></li>
            </ul>
          </div>
        </div>








    <!-- Partie principale -->
    <div class="container-fluid">
    <div class="row">
        <div class="d-none d-xl-block col-md-3 col-xl-2"></div>
        <main class="col-12 col-xl-10 col-lg-10 p-4 mt-5">
            <h1 class="text-center mb-4">Modifier Client</h1>
            <div class="container form">
                <div class="d-flex justify-content-center">


                <?php
                // Récupération de l'ID de la voiture
                      $v_IdClient = isset($_GET['id_client']) ? (int)$_GET['id_client'] : 0;
                      if ($v_IdClient <= 0) {
                          die("ID manquant ou invalide.");
                      }

                      // Récupération des données de la voiture
                      $query = mysqli_query($bdd, "SELECT * FROM client WHERE id_client = $v_IdClient");
                      if (!$query) {
                          die('Erreur SQL : ' . mysqli_error($bdd));
                      }
                      $result = mysqli_fetch_assoc($query);
                      if (!$result) {
                          die("Client non trouvé.");
                      }

                      // Préparation des valeurs pour remplir le formulaire
                      $db_nom = htmlspecialchars($result['nom']);
                      $db_prenom = htmlspecialchars($result['prenom']);
                      $db_username = htmlspecialchars($result['username']);
                      $db_email = htmlspecialchars($result['email']);
                      $db_numero = htmlspecialchars($result['numero']);


                      // Traitement du formulaire POST
                      if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
                          $form_IdClient = (int)$_POST['form_IdClient'];
                          $form_nom = mysqli_real_escape_string($bdd, $_POST['form_nom']);
                          $form_prenom = mysqli_real_escape_string($bdd, $_POST['form_prenom']);
                          $form_username = mysqli_real_escape_string($bdd, $_POST['form_username']);
                          $form_email = mysqli_real_escape_string($bdd, $_POST['form_email']);
                          $form_numero = mysqli_real_escape_string($bdd, $_POST['form_numero']);

                          // Mise à jour SQL
                          $sql = "
                              UPDATE client
                              SET nom = '$form_nom',
                                  prenom = '$form_prenom',
                                  email = '$form_email',
                                  numero = '$form_numero'
                              WHERE id_client = $form_IdClient
                          ";
                        

                          if (mysqli_query($bdd, $sql)) {
                          $message = "Mise à jour effectuée avec succès.";
                          $messageType = "alert-success";
                          } else {
                          $message = "Erreur lors de la mise à jour : " . mysqli_error($bdd);
                          $messageType = "alert-danger";
                          }
                      }
                    ?>
                  
            <div class="d-flex justify-content-center">
              
              <form name="ClientForm" method="POST" action="client_update.php?id_client=<?php echo $v_IdClient; ?>" enctype="multipart/form-data">
                
              <div class="d-flex justify-content-center my-5">
                <a href="client.php" class="button">Retour</a>
              </div>
              <?php if (isset($message) && !empty($message)): ?>
    <div class="alert <?= $messageType; ?> mt-3">
        <?= $message; ?>
    </div>
<?php endif; ?>

              <div class="row mb-5">
                            <div class="col-md-4">
                                <label for="nom" class="form-label">Nom</label>
                                <input type="text" name="form_nom" class="form-control" value="<?php echo $db_nom; ?>" required>
                            </div>

                            <div class="col-md-4">
                                <label for="prenom" class="form-label">Prénom</label>
                                <input type="text" name="form_prenom" class="form-control" value="<?php echo $db_prenom; ?>" required>
                            </div>

                            <div class="col-md-4">
                                <label for="username" class="form-label">Nom d'utilisateur</label>
                                <input type="text" name="form_username" class="form-control" value="<?php echo $db_username; ?>" readonly>
                            </div>
              </div>
<div class="row mb-5">
                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="form_email" class="form-control" value="<?php echo $db_email; ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label for="numero" class="form-label">Numéro</label>
                                <input type="number" name="form_numero" class="form-control" value="<?php echo $db_numero; ?>" required>
                            </div>
                        </div>
                        

                        <input type="hidden" name="form_IdClient" value="<?php echo $v_IdClient; ?>">

                        <div class="text-center mt-4">
                            <button type="submit" name="update" class="btn btn-primary">Enregistrer les modifications</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>