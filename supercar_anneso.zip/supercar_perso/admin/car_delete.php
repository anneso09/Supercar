<?php 
include("../config.php");
$id_voiture = $_GET['id_voiture'];
$result = mysqli_query($bdd, "DELETE FROM voiture WHERE id_voiture=$id_voiture");
header("Location:car.php");
?>