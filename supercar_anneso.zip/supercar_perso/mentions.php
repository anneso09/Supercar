<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Accueil</title>

</head>

<body>

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
      </nav>

      <h1>Mentions Légales</h1>

      

    <p>
        Ce site web est un projet pédagogique réalisé dans le cadre d’un BTS SIO (Services Informatiques aux Organisations).
        Les informations présentées ici sont fictives et n’ont pas vocation commerciale.
    </p>

    <h2>1. Éditeur du site</h2>
    <p>
        SuperCar<br>
        Adresse : MEF-MCCI Building, Ebène CyberCity, Ebène, Quatre Bornes<br>
        Téléphone : 57451793<br>
        Email : annesophie.montenot@gmail.com<br>
        Responsable de la publication : Anne-Sophie Montenot
    </p>

    <h2>2. Hébergement du site</h2>
    <p>
        Nom de l'hébergeur : AlwaysData<br>
        Adresse : 291 Rue du Faubourg Saint-Honoré, 75008 Paris, France<br>
        Téléphone : +33 1 84 16 23 40br>
        Site web : <a href="https://www.alwaysdata.com/en/">www.alwaysdata.com</a>
    </p>

    <h2>3. Propriété intellectuelle</h2>
    <p>
        Le contenu du site SuperCar (textes, images, logos, graphismes, etc.) est protégé par les lois en vigueur sur la propriété intellectuelle et appartient à SuperCar, sauf mention contraire.
        Toute reproduction, représentation ou diffusion, totale ou partielle, du contenu du site sans autorisation préalable est interdite.
    </p>

    <h2>4. Données personnelles</h2>
    <p>
        SuperCar s'engage à protéger la confidentialité des informations personnelles fournies par les utilisateurs du site. 
        Ces informations sont collectées uniquement à des fins pédagogiques et ne sont pas utilisées à des fins commerciales.
    </p>

    <h2>5. Responsabilité</h2>
    <p>
        SuperCar met tout en œuvre pour fournir des informations fiables et actualisées sur son site. Toutefois, des erreurs ou omissions peuvent survenir. 
        SuperCar décline toute responsabilité quant à l’utilisation qui pourrait être faite des informations diffusées sur le site.
    </p>

    <h2>6. Cookies</h2>
    <p>
        Le site SuperCar peut utiliser des cookies pour améliorer la navigation et collecter des statistiques. 
        Vous pouvez paramétrer votre navigateur pour refuser les cookies ou être averti de leur utilisation.
    </p>

    <h2>7. Droit applicable</h2>
    <p>
        Les présentes mentions légales sont soumises au droit français. En cas de litige, les tribunaux français seront seuls compétents.
    </p>
</body>
</html>