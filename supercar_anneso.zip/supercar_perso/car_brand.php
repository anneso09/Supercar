<!DOCTYPE HTML>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- CSS Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

    <!-- Liens vers les polices -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <title>Voitures</title>
</head>
<body>

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
      </nav>

    <!-- Section des voitures -->
    <?php
include("config.php");
$v_marque = isset($_GET['marque']) ? htmlspecialchars($_GET['marque']) : '';

echo '<div class="container mt-5 text-center">';
if (!empty($v_marque)) {
    echo '<h2>Nos voitures de la marque ' . ucfirst($v_marque) . '</h2>';
    $query = $bdd->prepare("SELECT * FROM voiture WHERE marque = ?");
    $query->bind_param("s", $v_marque);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        echo '<div class="row mt-4 g-4">';
        while ($row = $result->fetch_assoc()) {
            $modalId = "modal_" . preg_replace('/[^a-zA-Z0-9]/', '', $row['modele']);
            $carouselId = "carousel_" . preg_replace('/[^a-zA-Z0-9]/', '', $row['modele']);

            echo '<div class="col-12 col-md-4">';
            echo '<div class="card shadow-sm">';
            echo '<img src="' . htmlspecialchars($row['image_front']) . '" class="card-img-top img-fluid" alt="Image de ' . htmlspecialchars($row['modele']) . '" style="height: 200px; object-fit: cover;">';
            echo '<div class="card-body">';
            echo '<h5 class="card-title">' . htmlspecialchars($row['modele']) . '</h5>';
            echo '<p class="card-text">' . number_format($row['prix'], 0, ',', ' ') . ' €</p>';
            echo '<button type="button" class="button" data-bs-toggle="modal" data-bs-target="#' . $modalId . '">Voir détails</button>';
            echo '</div>';
            echo '</div>';
            echo '</div>';

            // MODAL Bootstrap
            echo '<div class="modal fade" id="' . $modalId . '" tabindex="-1" aria-labelledby="' . $modalId . 'Label" aria-hidden="true">';
            echo '<div class="modal-dialog modal-lg modal-dialog-centered">';
            echo '<div class="modal-content">';
            echo '<div class="modal-header">';
            echo '<h4 class="modal-title">' . htmlspecialchars($row['modele']) . '</h4>';
            echo '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>';
            echo '</div>';
            echo '<div class="modal-body text-center">';
            echo '<div id="' . $carouselId . '" class="carousel slide" data-bs-ride="carousel">';
            echo '<div class="carousel-inner">';

            $images = [htmlspecialchars($row['image_front']), htmlspecialchars($row['image_back'] ?? '')];
            $first = true;
            foreach ($images as $image) {
                if (!empty($image)) {
                    echo '<div class="carousel-item ' . ($first ? 'active' : '') . '">';
                    echo '<img src="' . $image . '" class="d-block w-100 rounded mb-3 img-fluid" alt="Image de ' . htmlspecialchars($row['modele']) . '">';
                    echo '</div>';
                    $first = false;
                }
            }

            echo '</div>';
            echo '<button class="carousel-control-prev" type="button" data-bs-target="#' . $carouselId . '" data-bs-slide="prev">';
            echo '<span class="carousel-control-prev-icon"></span>';
            echo '</button>';
            echo '<button class="carousel-control-next" type="button" data-bs-target="#' . $carouselId . '" data-bs-slide="next">';
            echo '<span class="carousel-control-next-icon"></span>';
            echo '</button>';
            echo '</div>';
            echo '<p>Prix : ' . number_format($row['prix'], 0, ',', ' ') . ' €</p>';
            echo '<p>' . htmlspecialchars($row['description_voiture']) . '</p>';
            echo '</div>';
            echo '<div class="modal-footer">';
            echo '<button class="button" onclick="location.href=\'essai.php?modele=' . urlencode($row['modele']) . '\'">Faire un essai</button>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>'; // Fermeture de la row
    } else {
        echo '<p>Aucune voiture trouvée pour cette marque.</p>';
    }
}
echo '</div>';
?>


    <!-- Script Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
