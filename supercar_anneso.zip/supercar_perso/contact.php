<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Accueil</title>

</head>

<body style="background-color: #FAFAFA;">

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
    </nav>

    <!-- Section hero -->
    <?php
// Include the database connection
include("config.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize input
    $v_nom = htmlspecialchars($_POST["fieldNom"]);
    $v_prenom = htmlspecialchars($_POST["fieldPrenom"]);
    $v_email = htmlspecialchars($_POST["fieldEmail"]);
    $v_num = htmlspecialchars($_POST["fieldPhoneNum"]);
    $v_message = htmlspecialchars($_POST["fieldMessage"]);

    // Prepare your SQL query to insert data into the "CONTACT" table
    $insertQuery = "INSERT INTO contact (nom, prenom, email, numero, message_contact) VALUES ('$v_nom', '$v_prenom', '$v_email', '$v_num', '$v_message' )";

    // Execute the query using mysqli_query
    if (mysqli_query($bdd, $insertQuery)) {
        $status = "Votre message a bien été envoyé!";
    } else {
        $status = "Error: " . mysqli_error($bdd);
    }
}

// Close the database connection
mysqli_close($bdd);
?>
<div class="container mt-5 d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="row w-100">
        <!-- Colonne pour l'image (Google Maps) -->
        <div class="col-xl-7 col-md-12 mb-4">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14407.819577038661!2d57.47680847186359!3d-20.24369805547519!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b1ef2170f63%3A0xd1a78020fc096491!2sMCCI%20BUSINESS%20SCHOOL%20(Mauritius%20Chamber%20of%20Commerce%20and%20Industry)!5e0!3m2!1sen!2smu!4v1741702609435!5m2!1sen!2smu" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>        
        </div>
        
        <!-- Colonne pour le formulaire -->
        <div class="col-xl-5 col-md-12 p-4 border rounded shadow-sm">
            <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <h2 class="text-center">Contactez-nous</h2>

                <div class="row">
                    <div class="col-md-6">
                        <label for="nom" class="form-label mt-2">Nom</label>
                        <input type="text" class="form-control form-control-sm" name="fieldNom" required>
                    </div>
                    <div class="col-md-6">
                        <label for="prenom" class="form-label mt-2">Prénom</label>
                        <input type="text" class="form-control form-control-sm" name="fieldPrenom" required>
                    </div>
                </div>

                <label for="phone number" class="form-label mt-2">Numéro de téléphone</label>
                <input type="tel" class="form-control form-control-sm" id="phone" name="fieldPhoneNum" inputmode="numeric" required>
                    <script>
                        document.getElementById('phone').addEventListener('input', function (e) {
                            this.value = this.value.replace(/[^0-9]/g, '');
                        });
                    </script>


                <label for="email" class="form-label mt-2">Email</label>
                <input type="email" class="form-control form-control-sm" name="fieldEmail" required>
                
                <label for="message" class="form-label mt-2">Message</label>
                <textarea name="fieldMessage" class="form-control form-control-sm" rows="2" required></textarea>

                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" class="form-control button btn-sm mt-3">Envoyer</button>
                    </div>
                    <div class="col-md-6">
                        <button type="reset" class="form-control button btn-sm mt-3">Annuler</button>
                    </div>
                </div>

                <div id="status" class="mt-2">
                    <?php if (isset($status)) echo $status; ?>
                </div>
            </form>
        </div>
    </div>
</div>


<section class="footer py-4">
        <div class="container">
            
            <div class="container my-4">
                <h4>Supercar © Copyright by Supercar</h4>
            </div>

            <div class="row text-center my-4">
                
                <div class="col-md-3">
                    <a href="contact.php">
                        Contact
                    </a>
                </div>
    
                <div class="col-md-3">
                    <a href="mentions.php">
                        Mentions légales
                    </a>
                </div>
                
                <div class="col-md-3">
                    <a href="politique.php">
                        Politiques de confidentialité
                    </a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>


            
            
        
        
  