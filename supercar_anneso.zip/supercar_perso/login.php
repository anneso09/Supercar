<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Connexion</title>

</head>

<body style="background-color: #FAFAFA;">
 

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
      </nav>

    

     <?php
session_start();
include("config.php"); // Connexion à la base de données

$status = ""; // Variable pour afficher le message

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['fieldUsername'], $_POST['fieldPassword'])) {
    $v_username = mysqli_real_escape_string($bdd, $_POST["fieldUsername"]);
    $v_password = $_POST["fieldPassword"];

    // Requête pour récupérer les informations de l'utilisateur
    $query = "SELECT * FROM client WHERE username = ?";
    $stmt = mysqli_prepare($bdd, $query);
    mysqli_stmt_bind_param($stmt, "s", $v_username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        // Comparaison du mot de passe en clair avec le mot de passe haché
        if (password_verify($v_password, $user['mot_de_passe'])) {
            $_SESSION['user_id'] = $user['id_client'];
            $_SESSION['username'] = $v_username;

            // Affiche un message de succès
            $status = "Connexion réussie ! Bienvenue, " . htmlspecialchars($v_username) . ".";
        } else {
            $status = "Mot de passe ou utilisateur incorrect.";
        }
    } else {
        $status = "Mot de passe ou utilisateur incorrect.";
    }

    mysqli_stmt_free_result($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($bdd);
}
?>







<div class="container mt-5 d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="row w-100">
        <!-- Colonne pour l'image (Google Maps) -->
        <div class="col-xl-7 col-md-12 mb-4">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14407.819577038661!2d57.47680847186359!3d-20.24369805547519!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b1ef2170f63%3A0xd1a78020fc096491!2sMCCI%20BUSINESS%20SCHOOL%20(Mauritius%20Chamber%20of%20Commerce%20and%20Industry)!5e0!3m2!1sen!2smu!4v1741702609435!5m2!1sen!2smu" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>        
        </div>
        
        <!-- Colonne pour le formulaire -->
        <div class="col-xl-5 col-md-12 p-4 border rounded shadow-sm d-flex flex-column justify-content-center">
            <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <h2 class="text-center">Connexion</h2>

                <div class="row">
                    <div class="col-md-6">
                        <label for="username" class="form-label mt-2">Nom d'utilisateur</label>
                        <input type="text" class="form-control form-control-sm" name="fieldUsername" required>
                    </div>
                    <div class="col-md-6">
                        <label for="password" class="form-label mt-2">Mot de passe</label>
                        <input type="password" class="form-control form-control-sm" name="fieldPassword" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" class="form-control button btn-sm mt-3">Envoyer</button>
                    </div>
                    <div class="col-md-6">
                        <button type="reset" class="form-control button btn-sm mt-3">Annuler</button>
                    </div>
                
                </div>

                
                <p class="mt-3 text-center">Vous n'avez pas encore de compte ? <a href="signup.php">Inscrivez-vous ici</a></p>
                <div id="status" class="mt-2">
                    
                    <?php if (isset($status)) echo "<p style='color: green;'>$status</p>"?>
                </div>
            </form>
        </div>
    </div>
</div>



</body>
</html>
