<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Voitures</title>

</head>

<body style="background-color: #FAFAFA;">
 

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
      </nav>

    

    <!-- Section des voitures -->

    <div class="container pt-5 text-center">
            <h2>Nos Voitures</h2>
    </div>

    <?php
include("config.php");
$selection = "SELECT * FROM voiture ORDER BY marque";
$curseur = mysqli_query($bdd, $selection);

if ($curseur) {
    if (mysqli_num_rows($curseur) > 0) {
        $currentMarque = '';
        $carCount = 0;

        echo '<section class="second-section">';
        echo '<div class="container my-5 text-center">';

        while ($row = mysqli_fetch_array($curseur)) {
            $v_marque = $row["marque"];
            $v_modele = $row["modele"];
            $v_prix = $row["prix"];
            $v_image_front = $row["image_front"];
            $v_image_back = $row["image_back"] ?? ''; 
            $v_description = $row["description_voiture"];

            $modalId = "modal_" . preg_replace('/[^a-zA-Z0-9]/', '', $v_modele);
            $carouselId = "carousel_" . preg_replace('/[^a-zA-Z0-9]/', '', $v_modele);

            if ($v_marque != $currentMarque) {
                if ($currentMarque != '') {
                    echo '<div class="col-12 text-center mt-3 my-5">';
                    echo '<a href="car_brand.php?marque=' . strtolower($currentMarque) . '" class="button">Voir toutes les voitures de ' . $currentMarque . '</a>';
                    echo '</div>';
                    echo '</div>'; // Fermeture de .row précédente
                }
                echo "<h2 class='text-center'>$v_marque</h2>";
                echo '<div class="row mt-4 g-4 justify-content-center">'; // Ajout de g-4 pour l'espacement
                $currentMarque = $v_marque;
                $carCount = 0;
            }

            if ($carCount < 3) {
                echo '<div class="col-12 col-md-4">'; // Utilisation de col-md-4 pour 3 cartes par ligne
                echo '<div class="card shadow-sm">';
                
                echo '<img src="' . htmlspecialchars($v_image_front) . '" class="card-img-top img-fluid" alt="Image de ' . htmlspecialchars($v_modele) . '" style="height: 200px; object-fit: cover;">';

                echo '</button>';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . htmlspecialchars($v_modele) . '</h5>';
                echo '<p class="card-text">' . number_format($v_prix, 0, ',', ' ') . ' €</p>';
                echo '<button type="button" class="button" data-bs-toggle="modal" data-bs-target="#' . $modalId . '">Voir détails</button>';
                echo '</div>';
                echo '</div>';
                echo '</div>';

                // MODAL Bootstrap
                echo '
                <div class="modal fade" id="' . $modalId . '" tabindex="-1" aria-labelledby="' . $modalId . 'Label" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">' . htmlspecialchars($v_modele) . '</h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body text-center">
                                <div id="' . $carouselId . '" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">';

                $images = [htmlspecialchars($v_image_front), htmlspecialchars($v_image_back)];
                $first = true;
                foreach ($images as $image) {
                    if (!empty($image)) {
                        echo '
                        <div class="carousel-item ' . ($first ? 'active' : '') . '">
                            <img src="' . $image . '" class="d-block w-100 rounded mb-3 img-fluid" alt="Image de ' . htmlspecialchars($v_modele) . '">
                        </div>';
                        $first = false;
                    }
                }

                echo '</div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#' . $carouselId . '" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#' . $carouselId . '" data-bs-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </button>
                                </div>
                                <p>Prix : ' . number_format($v_prix, 0, ',', ' ') . ' €</p>
                                <p>' . htmlspecialchars($v_description) . '</p>
                            </div>
                            <div class="modal-footer">
                                <button class="button" onclick="location.href=\'essai.php?modele=' . urlencode($v_modele) . '\'">Faire un essai</button>
                            </div>
                        </div>
                    </div>
                </div>';

                $carCount++;
            }
        }
        echo '<div class="col-12 text-center my-3">';
        echo '<a href="car_brand.php?marque=' . strtolower($currentMarque) . '" class="button">Voir toutes les voitures de ' . $currentMarque . '</a>';
        echo '</div>';
        echo '</div>'; // Fermeture de la dernière row
    }
}
echo '</div>';
echo '</section>';
?>


  

<section class="footer py-4">
        <div class="container">
            
            <div class="container my-4">
                <h4>Supercar © Copyright by Supercar</h4>
            </div>

            <div class="row text-center my-4">
                
                <div class="col-md-3">
                    <a href="contact.php">
                        Contact
                    </a>
                </div>
    
                <div class="col-md-3">
                    <a href="mentions.php">
                        Mentions légales
                    </a>
                </div>
                
                <div class="col-md-3">
                    <a href="politique.php">
                        Politiques de confidentialité
                    </a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
