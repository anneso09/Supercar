<!DOCTYPE HTML>
<html>
<head>

    <!-- Métadonnées de base -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Police DM Serif Text -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Text:ital@0;1&display=swap" rel="stylesheet">

    <!-- Police Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- CSS personnalisé -->
    <link href="style.css" rel="stylesheet">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Accueil</title>

</head>

<body>

    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand me-auto">
                <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
                SUPERCAR
            </a>

            <!-- Menu offcanvas -->
            <div class="offcanvas offcanvas-end" id="offcanvasNavbar" tabindex="-1" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body">

                    <!-- Liens de navigation -->
                    <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2 active" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="car_main.php">Voitures</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="essai.php">Demande d'essai</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mx-lg-2" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Icône utilisateur -->
            <a href="login.php"><img src="images/icon_user.png" alt="Utilisateur"></a>

            <!-- Bouton toggler -->
            <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" 
                    aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

        </div>
      </nav>

<h1>Politique de Confidentialité</h1>

    <p>
        Ce site web est un projet pédagogique réalisé dans le cadre d’un BTS SIO (Services Informatiques aux Organisations).
        Les informations collectées sont utilisées exclusivement à des fins pédagogiques et n’ont pas vocation commerciale.
    </p>

    <h2>1. Responsable du traitement</h2>
    <p>
        SuperCar<br>
        Adresse : MEF-MCCI Building, Ebène CyberCity, Ebène, Quatre Bornes<br>
        Téléphone : 57451793<br>
        Email : annesophie.montenot@gmail.com<br>
        Responsable de la publication : Anne-Sophie Montenot
    </p>

    <h2>2. Données collectées</h2>
    <p>
        SuperCar collecte et traite notamment les données suivantes à titre pédagogique :
        <ul>
            <li>Nom, prénom</li>
            <li>Adresse email</li>
            <li>Numéro de téléphone</li>
            <li>Adresse postale (si nécessaire pour les rendez-vous ou services)</li>
            <li>Identifiant de connexion et mot de passe (pour les comptes clients)</li>
            <li>Historique des prises de rendez-vous et demandes de services</li>
            <li>Messages envoyés via le formulaire de contact</li>
        </ul>
    </p>

    <h2>3. Finalités du traitement</h2>
    <p>
        Les données collectées sont utilisées uniquement à des fins pédagogiques :
    </p>
    <ul>
        <li>Gérer vos comptes clients et vos identifiants de connexion</li>
        <li>Gérer vos demandes d’essais, de services et vos rendez-vous</li>
        <li>Répondre à vos messages envoyés via le formulaire de contact</li>
        <li>Améliorer l’expérience utilisateur sur le site SuperCar</li>
    </ul>

    <h2>4. Conservation des données</h2>
    <p>
        Les données personnelles sont conservées uniquement le temps nécessaire au bon déroulement du projet pédagogique.
    </p>

    <h2>5. Destinataires des données</h2>
    <p>
        Les données collectées sont exclusivement destinées à SuperCar dans le cadre pédagogique et ne sont pas cédées à des tiers.
    </p>

    <h2>6. Sécurité des données</h2>
    <p>
        SuperCar met en place des mesures appropriées pour protéger vos données dans le cadre du projet pédagogique.
    </p>

    <h2>7. Vos droits</h2>
    <p>
        Conformément au RGPD, vous disposez des droits suivants :
        <ul>
            <li>Droit d’accès</li>
            <li>Droit de rectification</li>
            <li>Droit de suppression</li>
            <li>Droit de limitation du traitement</li>
            <li>Droit d’opposition</li>
            <li>Droit à la portabilité</li>
        </ul>
        Pour exercer vos droits, vous pouvez nous contacter à l’adresse mentionnée ci-dessus.
    </p>

    <h2>8. Cookies</h2>
    <p>
        Le site SuperCar peut utiliser des cookies à des fins pédagogiques pour améliorer la navigation et collecter des statistiques.
    </p>

    <h2>9. Modification de la politique de confidentialité</h2>
    <p>
        SuperCar se réserve le droit de modifier la présente politique à tout moment. Toute modification sera publiée sur cette page.
    </p>

    <h2>10. Contact</h2>
    <p>
        Pour toute question concernant vos données personnelles, vous pouvez nous contacter à : contact@supercar.com
    </p>
</body>
</html>